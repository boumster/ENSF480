/*
* File Name: GraphicsWorld.h
* Assignment: Lab 2 Exercise B
* Completed by: Jaden Haug-Uhrin and Phoenix Bouma
* Submission Date: Sept 20, 2024
*/
#ifndef GraphicsWorld_H
#define GraphicsWorld_H
#include <iostream>
using namespace std;

class GraphicsWorld
{
public:
    void run();
};

#endif
