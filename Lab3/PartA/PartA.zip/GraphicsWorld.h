/*
* File Name: GraphicsWorld.h
* Assignment: Lab 3 Exercise A
* Completed by: Jaden Haug-Uhrin and Phoenix Bouma
* Submission Date: Sept 27, 2024
*/
#ifndef GraphicsWorld_H
#define GraphicsWorld_H
#include <iostream>
using namespace std;

class GraphicsWorld
{
public:
    void run();
};

#endif
